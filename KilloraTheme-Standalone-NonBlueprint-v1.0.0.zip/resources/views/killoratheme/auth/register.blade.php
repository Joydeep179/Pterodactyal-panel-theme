<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Create account · Killora</title>
  <style>
    :root{color-scheme:dark;font-family:Inter,system-ui,-apple-system,"Segoe UI",sans-serif}
    *{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:28px 16px;background:radial-gradient(ellipse at 15% 10%,#433078 0,transparent 42%),radial-gradient(ellipse at 85% 90%,#173b70 0,transparent 38%),#080b16;color:#eef2ff}
    .register-shell{width:min(100%,480px);padding:30px;border:1px solid #ffffff2b;border-radius:22px;background:#0d1123a8;backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);box-shadow:0 24px 80px #0008}
    .brand{font-size:12px;letter-spacing:.22em;color:#c4b5fd;font-weight:800}.register-shell h1{margin:10px 0 6px;font-size:27px}.sub{margin:0 0 22px;color:#9ca9c2;font-size:13px}
    .grid{display:grid;grid-template-columns:1fr 1fr;gap:13px}.field{display:block;margin:0 0 14px;font-size:12px;color:#cbd5e1}.field input{display:block;width:100%;margin-top:7px;padding:12px 13px;border:1px solid #ffffff24;border-radius:10px;background:#080e1dcc;color:#fff;font:inherit;font-size:14px;outline:none}.field input:focus{border-color:#a78bfa;box-shadow:0 0 0 3px #8b5cf633}.wide{grid-column:1/-1}
    .submit{width:100%;padding:13px;border:0;border-radius:11px;background:linear-gradient(110deg,#4f46e5,#8b5cf6);color:white;font-weight:800;font-size:14px;cursor:pointer}.errors{padding:10px 12px;margin:0 0 16px;border:1px solid #f8717155;border-radius:10px;background:#7f1d1d33;color:#fecaca;font-size:12px}.footer{margin:18px 0 0;text-align:center;color:#9ca9c2;font-size:13px}.footer a{color:#c4b5fd;text-decoration:none;font-weight:700}.honeypot{position:absolute;left:-10000px;width:1px;height:1px;overflow:hidden}
    @media(max-width:440px){.register-shell{padding:23px 18px}.grid{grid-template-columns:1fr}.wide{grid-column:auto}}
  </style>
</head>
<body>
  <main class="register-shell">
    <div class="brand">KILLORA CLOUD</div>
    <h1>Create your account</h1>
    <p class="sub">Join the panel by completing the details below.</p>
    @if ($errors->any())
      <div class="errors" role="alert"><strong>Please check the following:</strong><ul style="margin:7px 0 0;padding-left:18px">@foreach ($errors->all() as $error)<li>{{ $error }}</li>@endforeach</ul></div>
    @endif
    <form method="POST" action="/killora-theme/register" autocomplete="on">
      @csrf
      <div class="honeypot" aria-hidden="true"><label>Leave this field empty<input name="website" tabindex="-1" autocomplete="off"></label></div>
      <div class="grid">
        <label class="field">Username<input name="username" value="{{ old('username') }}" required minlength="3" maxlength="32" autocomplete="username"></label>
        <label class="field">Email<input type="email" name="email" value="{{ old('email') }}" required maxlength="191" autocomplete="email"></label>
        <label class="field">First name<input name="first_name" value="{{ old('first_name') }}" required maxlength="191" autocomplete="given-name"></label>
        <label class="field">Last name<input name="last_name" value="{{ old('last_name') }}" required maxlength="191" autocomplete="family-name"></label>
        <label class="field wide">Password<input type="password" name="password" required minlength="12" autocomplete="new-password"></label>
        <label class="field wide">Confirm password<input type="password" name="password_confirmation" required minlength="12" autocomplete="new-password"></label>
      </div>
      <button class="submit" type="submit">Create account</button>
    </form>
    <p class="footer">Already have an account? <a href="/auth/login">Sign in</a></p>
  </main>
</body>
</html>
