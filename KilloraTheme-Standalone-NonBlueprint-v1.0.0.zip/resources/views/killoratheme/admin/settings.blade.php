<link rel="stylesheet" href="/extensions/killoratheme/assets/killora-studio.css">
<div class="content-wrapper killora-settings-page">
  <div class="killora-studio">
    <header class="killora-topbar">
      <div><span class="killora-kicker">KILLORA CLOUD · THEME STUDIO</span><h1>Killora Theme <small>v1.0.0</small></h1><p>One global design system for Admin, Client and Authentication pages.</p></div>
      <a class="killora-back" href="/admin">← Admin panel</a>
    </header>
    @if(session('success'))<div class="killora-notice success">{{ session('success') }}</div>@endif
    @if($errors->any())<div class="killora-notice error">{{ $errors->first() }}</div>@endif
    <form method="POST" action="/killora-theme/settings/save" enctype="multipart/form-data" id="killora-studio-form">
      @csrf
      <nav class="killora-tabs" aria-label="Theme settings">
        <button type="button" class="active" data-tab="branding">✦ Branding</button><button type="button" data-tab="dashboard">▦ Dashboard</button><button type="button" data-tab="sidebar">☷ Sidebar</button><button type="button" data-tab="palette">◉ Colors</button><button type="button" data-tab="auth">◇ Login</button><button type="button" data-tab="extras">⚙ Extras</button><button type="button" data-tab="performance">⚡ Performance</button>
      </nav>
      <main>
        <section class="killora-tab active" id="tab-branding">
          <div class="killora-section-head"><div><span>01 / GLOBAL BRANDING</span><h2>Background, logo & effects</h2><p>These settings are stored on the panel and shared with every user.</p></div></div>
          <div class="killora-grid">
            <article class="killora-card"><h3>🌌 Global background</h3>
              <label>Background media type<select name="background_type"><option value="image" @selected($settings['background_type']==='image')>Image</option><option value="gif" @selected($settings['background_type']==='gif')>Animated GIF</option><option value="video" @selected($settings['background_type']==='video')>Video (MP4 / WebM)</option></select></label>
              <label>Upload background<input type="file" name="background_file" accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm"><small>Up to 50 MB. Compressed media is recommended.</small></label>
              <label>Background opacity <output data-output="background_opacity">{{ $settings['background_opacity'] }}</output><input type="range" min="0.1" max="1" step="0.05" name="background_opacity" value="{{ $settings['background_opacity'] }}"></label>
              @if($settings['background_url'])<p class="killora-current">Active: <a href="{{ $settings['background_url'] }}" target="_blank" rel="noopener">Preview uploaded background ↗</a></p>@else<p class="killora-current">Using default Killora background.</p>@endif
            </article>
            <article class="killora-card"><h3>✧ Global logo</h3>
              <label>Logo media type<select name="logo_type"><option value="image" @selected($settings['logo_type']==='image')>Image</option><option value="gif" @selected($settings['logo_type']==='gif')>Animated GIF</option><option value="video" @selected($settings['logo_type']==='video')>Video (MP4 / WebM)</option></select></label>
              <label>Upload logo<input type="file" name="logo_file" accept="image/jpeg,image/png,image/webp,image/gif,video/mp4,video/webm"><small>Up to 20 MB. Transparent PNG or GIF works best.</small></label>
              @if($settings['logo_url'])<p class="killora-current">Active: <a href="{{ $settings['logo_url'] }}" target="_blank" rel="noopener">Preview uploaded logo ↗</a></p>@else<p class="killora-current">Using the panel's default logo.</p>@endif
            </article>
            <article class="killora-card"><h3>✨ Falling particles</h3>
              <label class="killora-toggle"><input type="checkbox" name="particle_enabled" value="1" @checked($settings['particle_enabled']==='1')> Enable global particles</label>
              <label>Effect<select name="particle_type">@foreach(['none'=>'Off','cherry-blossom'=>'Cherry Blossom','fire'=>'Fire','diamond-rain'=>'Diamond Rain','snow'=>'Snow','stars'=>'Stars','purple-magic'=>'Purple Magic','rain'=>'Rain','leaves'=>'Falling Leaves','sparkles'=>'Sparkles'] as $v=>$label)<option value="{{ $v }}" @selected($settings['particle_type']===$v)>{{ $label }}</option>@endforeach</select></label>
              <label>Density <output data-output="particle_density">{{ $settings['particle_density'] }}</output><input type="range" min="0" max="100" name="particle_density" value="{{ $settings['particle_density'] }}"></label>
              <label>Speed <output data-output="particle_speed">{{ $settings['particle_speed'] }}</output><input type="range" min="0.2" max="3" step="0.1" name="particle_speed" value="{{ $settings['particle_speed'] }}"></label>
              <label>Opacity <output data-output="particle_opacity">{{ $settings['particle_opacity'] }}</output><input type="range" min="0" max="1" step="0.05" name="particle_opacity" value="{{ $settings['particle_opacity'] }}"></label>
            </article>
          </div>
        </section>

        <section class="killora-tab" id="tab-dashboard">
          <div class="killora-section-head"><div><span>02 / CLIENT & ADMIN EXPERIENCE</span><h2>Dashboard layout</h2><p>Nebula-inspired dashboard controls with Killora styling.</p></div></div>
          <div class="killora-grid">
            <article class="killora-card"><h3>Dashboard appearance</h3>
              <label>Server list layout<select name="server_list"><option value="cards" @selected($settings['server_list']==='cards')>Cards</option><option value="list" @selected($settings['server_list']==='list')>Compact list</option></select></label>
              <label>Page transition<select name="animations"><option value="disabled" @selected($settings['animations']==='disabled')>Disabled</option><option value="fadein" @selected($settings['animations']==='fadein')>Fade in</option><option value="fadeup" @selected($settings['animations']==='fadeup')>Fade up</option><option value="zoomout" @selected($settings['animations']==='zoomout')>Zoom out</option></select></label>
              <label>Card corner radius <output data-output="border_radius">{{ $settings['border_radius'] }}</output><input type="range" min="0" max="30" name="border_radius" value="{{ $settings['border_radius'] }}"></label>
              <label>Dashboard transparency<select name="dashboard_transparency">@foreach(['0'=>'Opaque','1'=>'Subtle','2'=>'Transparent','3'=>'Maximum glass'] as $v=>$label)<option value="{{ $v }}" @selected($settings['dashboard_transparency']===$v)>{{ $label }}</option>@endforeach</select></label>
              <label>Background filter<select name="background_filter"><option value="none" @selected($settings['background_filter']==='none')>None</option><option value="dim" @selected($settings['background_filter']==='dim')>Dim</option><option value="blur" @selected($settings['background_filter']==='blur')>Blur</option></select></label>
              <label>Background sizing<select name="background_appearance"><option value="cover" @selected($settings['background_appearance']==='cover')>Cover</option><option value="contain" @selected($settings['background_appearance']==='contain')>Contain</option><option value="stretch" @selected($settings['background_appearance']==='stretch')>Stretch</option></select></label>
              <label>Background pattern<select name="background_pattern">@foreach(['none'=>'None','tiles'=>'Tiles','cubes'=>'Cubes','rotated-squares'=>'Rotated squares','l-shape'=>'L-shape','zig-zag'=>'Zig-zag','wavy-checkerboard'=>'Wavy checkerboard','chevrons'=>'Chevrons','houndstooth'=>'Houndstooth','quarter-circles'=>'Quarter circles','diagonal-rectangles'=>'Diagonal rectangles','alternating-arc'=>'Alternating arc','rotated-rectangles'=>'Rotated rectangles','concentric-arrows'=>'Concentric arrows','outline-triangles'=>'Outline triangles','moon'=>'Moon','polka'=>'Polka dots'] as $v=>$label)<option value="{{ $v }}" @selected($settings['background_pattern']===$v)>{{ $label }}</option>@endforeach</select></label>
              <label>Pattern size <output data-output="background_pattern_size">{{ $settings['background_pattern_size'] }}</output><input type="range" min="50" max="500" step="5" name="background_pattern_size" value="{{ $settings['background_pattern_size'] }}"></label>
            </article>
            <article class="killora-card"><h3>Dashboard controls</h3>
              @foreach(['keyboard_shortcuts'=>'Enable keyboard shortcuts','server_overview_graphs'=>'Show server overview graphs','server_colored_power'=>'Colored server power buttons','watermark'=>'Show dashboard watermark','keybind_icons'=>'Show icons in keybinds'] as $key=>$label)<label class="killora-toggle"><input type="checkbox" name="{{ $key }}" value="1" @checked($settings[$key]==='1')> {{ $label }}</label>@endforeach
              <label>Status indicator style<select name="statusgradient_style"><option value="default" @selected($settings['statusgradient_style']==='default')>Gradient</option><option value="flat" @selected($settings['statusgradient_style']==='flat')>Flat colors</option></select></label>
            </article>
          </div>
        </section>

        <section class="killora-tab" id="tab-sidebar">
          <div class="killora-section-head"><div><span>03 / NAVIGATION</span><h2>Sidebar & navigation</h2><p>Configure sidebar behavior, icon family, labels and shape.</p></div></div>
          <div class="killora-grid">
            <article class="killora-card"><h3>Sidebar behavior</h3>
              <label>Sidebar width<select name="sidebar_full"><option value="1" @selected($settings['sidebar_full']==='1')>Full / wide</option><option value="0" @selected($settings['sidebar_full']==='0')>Compact</option></select></label>
              <label>Hover behavior<select name="sidebar_hover"><option value="disabled" @selected($settings['sidebar_hover']==='disabled')>Disabled</option><option value="expand" @selected($settings['sidebar_hover']==='expand')>Expand</option><option value="popout" @selected($settings['sidebar_hover']==='popout')>Pop-out</option></select></label>
              <label>Sidebar surface<select name="sidebar_background"><option value="glass" @selected($settings['sidebar_background']==='glass')>Glass</option><option value="solid" @selected($settings['sidebar_background']==='solid')>Solid</option></select></label>
              <label>Tooltip style<select name="sidebar_hover_tooltip"><option value="off" @selected($settings['sidebar_hover_tooltip']==='off')>Off</option><option value="default" @selected($settings['sidebar_hover_tooltip']==='default')>Default</option><option value="aligned" @selected($settings['sidebar_hover_tooltip']==='aligned')>Aligned</option></select></label>
              <label>Button style<select name="sidebar_buttonstyle"><option value="default" @selected($settings['sidebar_buttonstyle']==='default')>Filled</option><option value="line" @selected($settings['sidebar_buttonstyle']==='line')>Line</option><option value="outline" @selected($settings['sidebar_buttonstyle']==='outline')>Outline</option></select></label>
              <label>Icon family<select name="icon_fallback">@foreach(['lucide'=>'Lucide','bootstrap'=>'Bootstrap','feather'=>'Feather','material'=>'Material','material-light'=>'Material Light','fontawesome'=>'Font Awesome','eva-outline'=>'Eva Outline','eva-solid'=>'Eva Solid','remix-outline'=>'Remix Outline','remix-solid'=>'Remix Solid','tabler'=>'Tabler','octicons'=>'Octicons','akaricons'=>'Akar Icons','hugeicons-solid'=>'Hugeicons Solid','hugeicons-stroke'=>'Hugeicons Stroke'] as $v=>$label)<option value="{{ $v }}" @selected($settings['icon_fallback']===$v)>{{ $label }}</option>@endforeach</select></label>
              <label>Icon scale <output data-output="icon_scale">{{ $settings['icon_scale'] }}</output><input type="range" min="0.5" max="1.8" step="0.05" name="icon_scale" value="{{ $settings['icon_scale'] }}"></label>
              <label>Sidebar corner radius <output data-output="sidebar_border_radius">{{ $settings['sidebar_border_radius'] }}</output><input type="range" min="0" max="30" name="sidebar_border_radius" value="{{ $settings['sidebar_border_radius'] }}"></label>
              @foreach(['sidebar_always_visible_buttons'=>'Always show sidebar buttons','sidebar_separators'=>'Show sidebar separators','sidebar_customlogo'=>'Use custom logo in sidebar'] as $key=>$label)<label class="killora-toggle"><input type="checkbox" name="{{ $key }}" value="1" @checked($settings[$key]==='1')> {{ $label }}</label>@endforeach
            </article>
            <article class="killora-card"><h3>Navigation labels</h3><p class="killora-help">Change the displayed wording without changing Pterodactyl routes or permissions.</p>
              @foreach(['sidebar_home'=>'Home','sidebar_admin'=>'Admin','sidebar_account'=>'Account','sidebar_logout'=>'Logout','sidebar_server_terminal'=>'Server: Console','sidebar_server_files'=>'Server: Files','sidebar_server_databases'=>'Server: Databases','sidebar_server_schedules'=>'Server: Schedules','sidebar_server_users'=>'Server: Users','sidebar_server_backups'=>'Server: Backups','sidebar_server_network'=>'Server: Network','sidebar_server_startup'=>'Server: Startup','sidebar_server_settings'=>'Server: Settings','sidebar_server_activity'=>'Server: Activity','sidebar_server_more'=>'Server: More','sidebar_account_account'=>'Account: Settings','sidebar_account_api'=>'Account: API','sidebar_account_ssh'=>'Account: SSH','sidebar_account_activity'=>'Account: Activity','sidebar_account_more'=>'Account: More'] as $key=>$label)<label>{{ $label }}<input type="text" maxlength="50" name="{{ $key }}" value="{{ $settings[$key] }}"></label>@endforeach
            </article>
          </div>
        </section>

        <section class="killora-tab" id="tab-palette">
          <div class="killora-section-head"><div><span>04 / COLOR SYSTEM</span><h2>Palette designer</h2><p>Choose colors for the dashboard, sidebar, login surface and server states.</p></div></div>
          <article class="killora-card"><h3>Dashboard palette</h3><label>Preset<select id="killora-palette-preset"><option value="custom">Custom</option><option value="default">Killora Midnight</option><option value="catppuccin">Catppuccin</option><option value="leaf">Leaf</option><option value="pyro">Pyro</option><option value="slate">Slate</option></select></label><div class="killora-colors">@for($i=1;$i<=9;$i++)<label>Color {{ $i }}<input type="color" name="palette_dashboard_{{ $i }}" value="{{ $settings['palette_dashboard_'.$i] }}"></label>@endfor</div></article>
          <article class="killora-card"><h3>Sidebar palette</h3><div class="killora-colors">@for($i=1;$i<=8;$i++)<label>Color {{ $i }}<input type="color" name="palette_sidebar_{{ $i }}" value="{{ $settings['palette_sidebar_'.$i] }}"></label>@endfor</div></article>
          <article class="killora-card"><h3>Authentication palette</h3><div class="killora-colors">@for($i=1;$i<=8;$i++)<label>Color {{ $i }}<input type="color" name="palette_auth_{{ $i }}" value="{{ $settings['palette_auth_'.$i] }}"></label>@endfor</div></article>
          <article class="killora-card"><h3>Server status colors</h3><div class="killora-colors">@foreach(['online'=>'Online','starting'=>'Starting','error'=>'Error','offline'=>'Offline'] as $key=>$label)<label>{{ $label }}<input type="color" name="palette_status_{{ $key }}" value="{{ $settings['palette_status_'.$key] }}"></label>@endforeach</div></article>
        </section>

        <section class="killora-tab" id="tab-auth">
          <div class="killora-section-head"><div><span>05 / AUTHENTICATION</span><h2>Login & glass appearance</h2><p>Nebula-inspired floating login panel, with the Killora glass treatment.</p></div></div>
          <div class="killora-grid">
            <article class="killora-card"><h3>Login background</h3>
              <label>Background source<select name="auth_background_mode"><option value="global" @selected($settings['auth_background_mode']==='global')>Use global background</option><option value="pattern" @selected($settings['auth_background_mode']==='pattern')>Pattern overlay</option><option value="custom" @selected($settings['auth_background_mode']==='custom')>Use uploaded global media</option></select></label>
              <label>Pattern<select name="auth_background_pattern">@foreach(['none'=>'None','tiles'=>'Tiles','cubes'=>'Cubes','zig-zag'=>'Zig-zag','chevrons'=>'Chevrons','polka'=>'Polka','moon'=>'Moon','houndstooth'=>'Houndstooth'] as $v=>$label)<option value="{{ $v }}" @selected($settings['auth_background_pattern']===$v)>{{ $label }}</option>@endforeach</select></label>
              <label>Login background filter<select name="auth_background_filter"><option value="none" @selected($settings['auth_background_filter']==='none')>None</option><option value="dim" @selected($settings['auth_background_filter']==='dim')>Dim</option><option value="blur" @selected($settings['auth_background_filter']==='blur')>Blur</option></select></label>
              <label>Image sizing<select name="auth_background_appearance"><option value="cover" @selected($settings['auth_background_appearance']==='cover')>Cover</option><option value="contain" @selected($settings['auth_background_appearance']==='contain')>Contain</option><option value="stretch" @selected($settings['auth_background_appearance']==='stretch')>Stretch</option></select></label>
              <label class="killora-toggle"><input type="checkbox" name="watermark_auth" value="1" @checked($settings['watermark_auth']==='1')> Show authentication watermark</label>
              <label class="killora-toggle"><input type="checkbox" name="auth_customlogo" value="1" @checked($settings['auth_customlogo']==='1')> Show custom logo on login</label>
            </article>
            <article class="killora-card"><h3>Account registration</h3>
              <label class="killora-toggle"><input type="checkbox" name="registration_enabled" value="1" @checked($settings['registration_enabled']==='1')> Enable public registration</label>
              <p class="killora-help">When enabled, a Register button appears on the login page. Visitors can create standard non-admin accounts with username, first name, last name, email and password. Registration is rate-limited; passwords must be at least 12 characters.</p>
            </article>
            <article class="killora-card"><h3>Glass login card</h3>
              <label>Glass blur <output data-output="glass_blur">{{ $settings['glass_blur'] }}</output><input type="range" min="0" max="30" name="glass_blur" value="{{ $settings['glass_blur'] }}"></label>
              <div class="killora-glass-preview"><div><span>KILLORA</span><strong>Welcome back</strong><small>Glassmorphism preview</small></div></div>
            </article>
          </div>
        </section>

        <section class="killora-tab" id="tab-extras">
          <div class="killora-section-head"><div><span>06 / EXTRAS</span><h2>Links, notices & utility</h2><p>Extra quality-of-life controls inspired by the supplied theme set.</p></div></div>
          <div class="killora-grid">
            <article class="killora-card"><h3>Website links</h3><label class="killora-toggle"><input type="checkbox" name="website_links" value="1" @checked($settings['website_links']==='1')> Enable website links</label>
              @foreach(['weblink_support'=>'Support URL','weblink_billing'=>'Billing URL','weblink_status'=>'Status page URL','weblink_social_discord'=>'Discord URL','weblink_social_github'=>'GitHub URL'] as $key=>$label)<label>{{ $label }}<input type="url" name="{{ $key }}" value="{{ $settings[$key] }}" placeholder="https://"></label>@endforeach
              <label>Link alignment<select name="website_links_align"><option value="left" @selected($settings['website_links_align']==='left')>Left</option><option value="right" @selected($settings['website_links_align']==='right')>Right</option></select></label>
            </article>
            <article class="killora-card"><h3>Global announcement</h3><label class="killora-toggle"><input type="checkbox" name="alert" value="1" @checked($settings['alert']==='1')> Enable announcement banner</label>
              <label>Announcement text<textarea name="alert_text" rows="3" maxlength="500">{{ $settings['alert_text'] }}</textarea></label>
              <label>Icon<select name="alert_icon">@foreach(['database'=>'Database','gear'=>'Settings','megaphone'=>'Megaphone','message'=>'Message','reception'=>'Signal','rocket'=>'Rocket','success'=>'Success','warning'=>'Warning'] as $v=>$label)<option value="{{ $v }}" @selected($settings['alert_icon']===$v)>{{ $label }}</option>@endforeach</select></label>
              <label>Position<select name="alert_position"><option value="static" @selected($settings['alert_position']==='static')>Static</option><option value="sticky" @selected($settings['alert_position']==='sticky')>Sticky</option></select></label>
              <label class="killora-toggle"><input type="checkbox" name="alert_dismiss" value="1" @checked($settings['alert_dismiss']==='1')> Allow users to dismiss</label>
            </article>
            <article class="killora-card"><h3>Miscellaneous</h3><label class="killora-toggle"><input type="checkbox" name="page_indexing" value="1" @checked($settings['page_indexing']==='1')> Enable page indexing helper</label><p class="killora-help">This stores the preference for the theme runtime. It does not alter Pterodactyl permissions or server access.</p></article>
          </div>
        </section>

        <section class="killora-tab" id="tab-performance">
          <div class="killora-section-head"><div><span>07 / PERFORMANCE</span><h2>Optimization controls</h2><p>Keep the visual effects lightweight on phones and lower-powered computers.</p></div></div>
          <div class="killora-grid">
            <article class="killora-card"><h3>Low-end mode</h3><label class="killora-toggle"><input type="checkbox" name="low_end_default" value="1" @checked($settings['low_end_default']==='1')> Enable Low-End Mode by default for everyone</label><p class="killora-help">Reduces or disables decorative effects, limits particle count and avoids autoplay video backgrounds on constrained devices.</p></article>
            <article class="killora-card"><h3>Runtime safeguards</h3><ul class="killora-checklist"><li>Canvas particle count and device-pixel-ratio caps</li><li>Pause animation when the tab is hidden</li><li>Respect operating-system reduced-motion preference</li><li>Skip heavy video backgrounds on low-end devices</li><li>Lazy-load media and keep UI effects decorative only</li></ul><p class="killora-help">Static images are the best choice for battery life and slower connections.</p></article>
          </div>
        </section>
      </main>
      <footer class="killora-savebar"><div><strong>Changes apply globally</strong><small>Saved in the panel's Blueprint database, not only in this browser.</small></div><button type="submit">Save all theme settings ↗</button></footer>
    </form>
  </div>
</div>
<script>
(() => {
 const root=document.querySelector('.killora-settings-page'); if(!root)return;
 const tabs=[...root.querySelectorAll('[data-tab]')], panels=[...root.querySelectorAll('.killora-tab')];
 tabs.forEach(btn=>btn.addEventListener('click',()=>{tabs.forEach(b=>b.classList.toggle('active',b===btn));panels.forEach(p=>p.classList.toggle('active',p.id==='tab-'+btn.dataset.tab));}));
 const presets={default:['#171a2b','#222640','#292e4a','#353b5c','#a78bfa','#8b5cf6','#c4b5fd','#e9eaff','#ffffff'],catppuccin:['#1e1e2e','#313244','#45475a','#585b70','#cba6f7','#f5c2e7','#89b4fa','#cdd6f4','#ffffff'],leaf:['#17251d','#24382b','#34513b','#49694b','#a3be8c','#8fbc8f','#d5e8c5','#e5f1dc','#ffffff'],pyro:['#21151a','#3c1e25','#5a2630','#78313a','#ff6b35','#ff9f1c','#ffd166','#ffe8c2','#ffffff'],slate:['#171c26','#242d3b','#354255','#46566d','#8da9c4','#6f8ba8','#c3d2e2','#e1e8f0','#ffffff']};const preset=root.querySelector('#killora-palette-preset');if(preset)preset.addEventListener('change',()=>{(presets[preset.value]||[]).forEach((v,i)=>{const input=root.querySelector('[name="palette_dashboard_'+(i+1)+'"]');if(input)input.value=v;});});
 root.querySelectorAll('input[type="range"]').forEach(input=>{const out=root.querySelector('[data-output="'+input.name+'"]');const update=()=>{if(out)out.value=input.value;};input.addEventListener('input',update);update();});
})();
</script>
