#!/usr/bin/env bash
set -euo pipefail
PANEL="${1:-/var/www/pterodactyl}"
[ -f "$PANEL/artisan" ] || { echo "Usage: bash install.sh /var/www/pterodactyl"; exit 1; }
SRC="$(cd "$(dirname "$0")" && pwd)"
backup="$PANEL/storage/app/killoratheme-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$backup"
cp "$PANEL/routes/web.php" "$backup/web.php"
mkdir -p "$PANEL/app/Http/Controllers/Admin/Extensions/killoratheme"
cp "$SRC/admin/Controller.php" "$PANEL/app/Http/Controllers/Admin/Extensions/killoratheme/KilloraThemeExtensionController.php"
mkdir -p "$PANEL/resources/views/killoratheme/admin" "$PANEL/resources/views/killoratheme/auth"
cp "$SRC/resources/views/killoratheme/admin/settings.blade.php" "$PANEL/resources/views/killoratheme/admin/settings.blade.php"
cp "$SRC/resources/views/killoratheme/auth/register.blade.php" "$PANEL/resources/views/killoratheme/auth/register.blade.php"
mkdir -p "$PANEL/public/extensions/killoratheme/assets" "$PANEL/public/extensions/killoratheme/uploads"
cp "$SRC/public/assets/"* "$PANEL/public/extensions/killoratheme/assets/"
chmod -R 755 "$PANEL/public/extensions/killoratheme"
touch "$PANEL/storage/app/killoratheme/settings.json"
chown -R www-data:www-data "$PANEL/storage/app/killoratheme" "$PANEL/public/extensions/killoratheme/uploads" 2>/dev/null || true
if ! grep -q "killoratheme/install/routes.php" "$PANEL/routes/web.php"; then
  printf "\n// Killora Theme (standalone, non-Blueprint)\nrequire base_path('killoratheme/install/routes.php');\n" >> "$PANEL/routes/web.php"
fi
mkdir -p "$PANEL/killoratheme/install"
cp "$SRC/install/routes.php" "$PANEL/killoratheme/install/routes.php"
# A persistent floating editor shortcut, shown only to root administrators.
mkdir -p "$PANEL/resources/views/killoratheme"
cat > "$PANEL/resources/views/killoratheme/admin-shortcut.blade.php" <<'BLADE'
@if(auth()->check() && auth()->user()->root_admin)
<a href="{{ route('killora-theme.editor') }}" style="position:fixed;right:18px;bottom:18px;z-index:99999;background:#7c3aed;color:#fff;padding:12px 17px;border-radius:12px;font-weight:700;text-decoration:none;box-shadow:0 8px 30px #0006">✦ Killora Theme Editor</a>
@endif
BLADE
# Inject shortcut into admin layout once. If layout differs, provide direct route anyway.
layout="$PANEL/resources/views/layouts/admin.blade.php"
if [ -f "$layout" ]; then
  if ! grep -q "killoratheme.admin-shortcut" "$layout"; then
    sed -i 's#</body>#@include("killoratheme::admin-shortcut")\\n</body>#' "$layout"
  fi
  if ! grep -q "killora-runtime.js" "$layout"; then
    sed -i 's#</body>#<script defer src="/extensions/killoratheme/assets/killora-runtime.js"></script>\\n</body>#' "$layout"
  fi
fi
client_layout="$PANEL/resources/views/layouts/app.blade.php"
if [ -f "$client_layout" ] && ! grep -q "killora-runtime.js" "$client_layout"; then
  sed -i 's#</body>#<script defer src="/extensions/killoratheme/assets/killora-runtime.js"></script>\\n</body>#' "$client_layout"
fi
cd "$PANEL"
php artisan view:clear
php artisan route:clear
php artisan config:clear
echo "Installed. Open Admin panel; use the floating Killora Theme Editor button."
echo "Direct editor route: /killora-theme/editor"
echo "Backup: $backup"
