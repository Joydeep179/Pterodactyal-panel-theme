<?php
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\View;
use Pterodactyl\Http\Controllers\Admin\Extensions\killoratheme\KilloraThemeExtensionController;

View::addNamespace('killoratheme', resource_path('views/killoratheme'));

Route::middleware(['web'])->prefix('killora-theme')->group(function () {
    Route::get('/config', [KilloraThemeExtensionController::class, 'publicConfig'])->name('killora-theme.config');
    Route::get('/register', [KilloraThemeExtensionController::class, 'showRegistration'])->middleware('guest')->name('killora-theme.register');
    Route::post('/register', [KilloraThemeExtensionController::class, 'register'])->middleware(['guest', 'throttle:5,1'])->name('killora-theme.register.submit');
});
Route::middleware(['web', 'auth'])->prefix('killora-theme')->group(function () {
    Route::get('/editor', [KilloraThemeExtensionController::class, 'index'])->name('killora-theme.editor');
    Route::post('/settings/save', [KilloraThemeExtensionController::class, 'update'])->name('killora-theme.settings.save');
});
