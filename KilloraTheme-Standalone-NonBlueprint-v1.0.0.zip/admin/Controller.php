<?php

namespace Pterodactyl\Http\Controllers\Admin\Extensions\killoratheme;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Hash;
use Pterodactyl\Models\User;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\BlueprintFramework\Libraries\ExtensionLibrary\Admin\BlueprintAdminLibrary as BlueprintExtensionLibrary;
use Symfony\Component\HttpKernel\Exception\AccessDeniedHttpException;

class KilloraThemeExtensionController extends Controller
{
    private const KEY = 'killoratheme';

    private function settingsFile(): string
    {
        return storage_path('app/killoratheme/settings.json');
    }

    private function readStoredSettings(): array
    {
        $path = $this->settingsFile();
        if (!is_file($path)) return [];
        $data = json_decode(file_get_contents($path), true);
        return is_array($data) ? $data : [];
    }

    private function writeStoredSettings(array $settings): void
    {
        $path = $this->settingsFile();
        File::ensureDirectoryExists(dirname($path));
        File::put($path, json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    }

    private function defaults(): array
    {
        $defaults = [
            'background_url' => '', 'background_type' => 'image', 'background_opacity' => '0.72',
            'registration_enabled' => '0',
            'logo_url' => '', 'logo_type' => 'image', 'particle_type' => 'none',
            'particle_enabled' => '0', 'particle_density' => '35', 'particle_speed' => '1',
            'particle_opacity' => '0.75', 'glass_blur' => '16', 'low_end_default' => '0',
            'auth_background_mode' => 'global', 'auth_background_pattern' => 'none',
            'auth_background_appearance' => 'cover', 'auth_background_filter' => 'dim', 'background_filter' => 'dim', 'watermark_auth' => '0', 'auth_customlogo' => '1',
            'server_list' => 'cards', 'animations' => 'fadeup', 'keyboard_shortcuts' => '1',
            'server_overview_graphs' => '1', 'server_colored_power' => '1', 'watermark' => '0',
            'border_radius' => '14', 'background_appearance' => 'cover', 'background_pattern' => 'none',
            'background_pattern_size' => '215', 'dashboard_transparency' => '2', 'keybind_icons' => '1',
            'statusgradient_style' => 'default', 'icon_fallback' => 'lucide', 'sidebar_full' => '1',
            'sidebar_hover' => 'expand', 'sidebar_background' => 'glass', 'sidebar_always_visible_buttons' => '1',
            'sidebar_separators' => '1', 'sidebar_border_radius' => '12', 'icon_scale' => '0.9',
            'sidebar_hover_tooltip' => 'default', 'sidebar_buttonstyle' => 'default', 'sidebar_customlogo' => '1',
            'page_indexing' => '0', 'website_links' => '0', 'website_links_align' => 'left',
            'weblink_support' => '', 'weblink_billing' => '', 'weblink_status' => '',
            'weblink_social_discord' => '', 'weblink_social_github' => '', 'alert' => '0',
            'alert_text' => '', 'alert_icon' => 'megaphone', 'alert_position' => 'static', 'alert_dismiss' => '1',
            'sidebar_home' => 'Home', 'sidebar_admin' => 'Admin', 'sidebar_account' => 'Account',
            'sidebar_logout' => 'Logout', 'sidebar_server_terminal' => 'Console', 'sidebar_server_files' => 'Files',
            'sidebar_server_databases' => 'Databases', 'sidebar_server_schedules' => 'Schedules',
            'sidebar_server_users' => 'Users', 'sidebar_server_backups' => 'Backups', 'sidebar_server_network' => 'Network',
            'sidebar_server_startup' => 'Startup', 'sidebar_server_settings' => 'Settings',
            'sidebar_server_activity' => 'Activity', 'sidebar_server_more' => 'More',
            'sidebar_account_account' => 'Account settings', 'sidebar_account_api' => 'API credentials',
            'sidebar_account_ssh' => 'SSH keys', 'sidebar_account_activity' => 'Activity', 'sidebar_account_more' => 'More',
        ];
        $paletteDefaults = ['dashboard'=>['171a2b','222640','292e4a','353b5c','a78bfa','8b5cf6','c4b5fd','e9eaff','ffffff'], 'sidebar'=>['ffffff','ffffff','171a2b','222640','292e4a','a78bfa','080b16','8b5cf6'], 'auth'=>['ffffff','e9eaff','a78bfa','8b5cf6','171a2b','222640','c4b5fd','ffffff']];
        foreach ($paletteDefaults as $group=>$colors) foreach ($colors as $i=>$color) $defaults['palette_'.$group.'_'.($i+1)] = '#'.$color;
        foreach (['online'=>'#22c55e','starting'=>'#f59e0b','error'=>'#ef4444','offline'=>'#94a3b8'] as $state=>$color) $defaults['palette_status_'.$state]=$color;
        return $defaults;
    }

    private function settings(): array
    {
        $out = [];
        foreach ($this->defaults() as $key => $default) {
            $stored = $this->readStoredSettings();
            $value = $stored[$key] ?? null;
            $out[$key] = ($value === null || $value === '') ? $default : $value;
        }
        return $out;
    }

    private function adminOnly(Request $request): void
    {
        if (!$request->user() || !$request->user()->root_admin) {
            throw new AccessDeniedHttpException();
        }
    }

    public function index(Request $request)
    {
        $this->adminOnly($request);
        return view('killoratheme::admin.settings', [
            'settings' => $this->settings(),
        ]);
    }

    public function publicConfig()
    {
        $s = $this->settings();
        $palette = [];
        foreach (['dashboard','sidebar','auth'] as $group) {
            for ($i=1; $i<=($group === 'dashboard' ? 9 : 8); $i++) $palette[$group][$i] = $s['palette_'.$group.'_'.$i];
        }
        foreach (['online','starting','error','offline'] as $state) $palette['status'][$state] = $s['palette_status_'.$state];
        $keys = array_keys($s);
        $public = [];
        foreach ($keys as $key) {
            if (str_starts_with($key, 'weblink_') || in_array($key, ['alert_text'], true)) continue;
            $public[$key] = $s[$key];
        }
        return response()->json([
            'background' => ['url'=>$s['background_url'], 'type'=>$s['background_type'], 'opacity'=>(float)$s['background_opacity']],
            'logo' => ['url'=>$s['logo_url'], 'type'=>$s['logo_type']],
            'particles' => ['enabled'=>$s['particle_enabled']==='1', 'type'=>$s['particle_type'], 'density'=>(int)$s['particle_density'], 'speed'=>(float)$s['particle_speed'], 'opacity'=>(float)$s['particle_opacity']],
            'glassBlur'=>(int)$s['glass_blur'], 'lowEndDefault'=>$s['low_end_default']==='1',
            'registrationEnabled'=>$s['registration_enabled']==='1',
            'palette'=>$palette, 'theme'=>$public,
            'announcement'=>['enabled'=>$s['alert']==='1','text'=>$s['alert_text'],'icon'=>$s['alert_icon'],'position'=>$s['alert_position'],'dismissible'=>$s['alert_dismiss']==='1'],
            'links'=>['enabled'=>$s['website_links']==='1','align'=>$s['website_links_align'],'items'=>array_filter(['Support'=>$s['weblink_support'],'Billing'=>$s['weblink_billing'],'Status'=>$s['weblink_status'],'Discord'=>$s['weblink_social_discord'],'GitHub'=>$s['weblink_social_github']])],
        ])->header('Cache-Control', 'public, max-age=45');
    }

    private function registrationIsEnabled(): bool
    {
        return ($this->readStoredSettings()['registration_enabled'] ?? '0') === '1';
    }

    public function showRegistration(Request $request)
    {
        abort_unless($this->registrationIsEnabled(), 404);
        if ($request->user()) return redirect('/');

        return view('killoratheme::auth.register');
    }

    public function register(Request $request)
    {
        abort_unless($this->registrationIsEnabled(), 404);
        if ($request->user()) return redirect('/');

        // Honeypot field: real visitors leave this empty.
        if ($request->filled('website')) {
            abort(422, 'Unable to process registration.');
        }

        $validated = $request->validate([
            'username' => ['required', 'string', 'min:3', 'max:32', 'alpha_dash', 'unique:users,username'],
            'first_name' => ['required', 'string', 'max:191'],
            'last_name' => ['required', 'string', 'max:191'],
            'email' => ['required', 'string', 'email', 'max:191', 'unique:users,email'],
            'password' => ['required', 'string', 'min:12', 'confirmed'],
        ], [
            'password.confirmed' => 'The password confirmation does not match.',
            'username.unique' => 'That username is already in use.',
            'email.unique' => 'An account with that email already exists.',
        ]);

        $user = new User();
        $user->username = $validated['username'];
        $user->name_first = $validated['first_name'];
        $user->name_last = $validated['last_name'];
        $user->email = $validated['email'];
        $user->password = Hash::make($validated['password']);
        $user->language = 'en';
        $user->root_admin = false;
        $user->use_totp = false;
        $user->save();

        return redirect('/auth/login')->with('success', 'Your account has been created. You can now sign in.');
    }

    public function update(Request $request)
    {
        $this->adminOnly($request);
        $request->validate([
            'background_type'=>'required|in:image,gif,video', 'logo_type'=>'required|in:image,gif,video',
            'particle_type'=>'required|in:none,cherry-blossom,fire,diamond-rain,snow,stars,purple-magic,rain,leaves,sparkles',
            'background_opacity'=>'required|numeric|min:0.1|max:1', 'particle_density'=>'required|integer|min:0|max:100',
            'particle_speed'=>'required|numeric|min:0.2|max:3', 'particle_opacity'=>'required|numeric|min:0|max:1',
            'glass_blur'=>'required|integer|min:0|max:30',
            'background_file'=>'nullable|file|mimes:jpg,jpeg,png,webp,gif,mp4,webm|max:51200',
            'logo_file'=>'nullable|file|mimes:jpg,jpeg,png,webp,gif,mp4,webm|max:20480',
        ]);
        $settings = [
            'background_type'=>$request->input('background_type'), 'background_opacity'=>(string)$request->input('background_opacity'),
            'logo_type'=>$request->input('logo_type'), 'particle_type'=>$request->input('particle_type'),
            'particle_enabled'=>$request->boolean('particle_enabled')?'1':'0', 'particle_density'=>(string)$request->input('particle_density'),
            'particle_speed'=>(string)$request->input('particle_speed'), 'particle_opacity'=>(string)$request->input('particle_opacity'),
            'glass_blur'=>(string)$request->input('glass_blur'), 'low_end_default'=>$request->boolean('low_end_default')?'1':'0',
        ];
        $enum = [
            'auth_background_mode'=>['global','pattern','custom'], 'auth_background_pattern'=>['none','tiles','cubes','zig-zag','chevrons','polka','moon','houndstooth'],
            'auth_background_appearance'=>['cover','contain','stretch'], 'auth_background_filter'=>['none','dim','blur'], 'background_filter'=>['none','dim','blur'], 'server_list'=>['cards','list'],
            'animations'=>['disabled','fadein','fadeup','zoomout'], 'background_appearance'=>['cover','contain','stretch'],
            'background_pattern'=>['none','tiles','cubes','rotated-squares','l-shape','zig-zag','wavy-checkerboard','chevrons','houndstooth','quarter-circles','diagonal-rectangles','alternating-arc','rotated-rectangles','concentric-arrows','outline-triangles','moon','polka'],
            'dashboard_transparency'=>['0','1','2','3'], 'statusgradient_style'=>['default','flat'],
            'icon_fallback'=>['akaricons','bootstrap','feather','lucide','material','material-light','fontawesome','eva-outline','eva-solid','remix-outline','remix-solid','tabler','octicons','hugeicons-solid','hugeicons-stroke'],
            'sidebar_hover'=>['disabled','expand','popout'], 'sidebar_background'=>['glass','solid'],
            'sidebar_hover_tooltip'=>['off','default','aligned'], 'sidebar_buttonstyle'=>['default','line','outline'],
            'website_links_align'=>['left','right'], 'alert_icon'=>['database','gear','megaphone','message','reception','rocket','success','warning'],
            'alert_position'=>['static','sticky'],
        ];
        foreach ($enum as $key=>$allowed) if ($request->has($key)) $settings[$key] = in_array((string)$request->input($key), $allowed, true) ? (string)$request->input($key) : $this->defaults()[$key];
        $bools = ['registration_enabled','watermark_auth','auth_customlogo','keyboard_shortcuts','server_overview_graphs','server_colored_power','watermark','keybind_icons','sidebar_full','sidebar_always_visible_buttons','sidebar_separators','sidebar_customlogo','page_indexing','website_links','alert','alert_dismiss'];
        foreach ($bools as $key) $settings[$key] = $request->boolean($key) ? '1' : '0';
        $ranges = ['border_radius'=>[0,30],'background_pattern_size'=>[50,500],'sidebar_border_radius'=>[0,30],'icon_scale'=>[0.5,1.8]];
        foreach ($ranges as $key=>[$min,$max]) if ($request->has($key) && is_numeric($request->input($key))) $settings[$key] = (string)max($min,min($max,(float)$request->input($key)));
        for ($i=1;$i<=9;$i++) if ($request->has('palette_dashboard_'.$i)) $settings['palette_dashboard_'.$i] = preg_match('/^#[0-9a-fA-F]{6}$/',(string)$request->input('palette_dashboard_'.$i)) ? $request->input('palette_dashboard_'.$i) : '#171a2b';
        foreach (['sidebar','auth'] as $group) for ($i=1;$i<=8;$i++) { $key='palette_'.$group.'_'.$i; if($request->has($key)) $settings[$key]=preg_match('/^#[0-9a-fA-F]{6}$/',(string)$request->input($key))?$request->input($key):'#ffffff'; }
        foreach (['online','starting','error','offline'] as $state) { $key='palette_status_'.$state; if($request->has($key)) $settings[$key]=preg_match('/^#[0-9a-fA-F]{6}$/',(string)$request->input($key))?$request->input($key):'#94a3b8'; }
        $textKeys = ['alert_text','weblink_support','weblink_billing','weblink_status','weblink_social_discord','weblink_social_github',
            'sidebar_home','sidebar_admin','sidebar_account','sidebar_logout','sidebar_server_terminal','sidebar_server_files','sidebar_server_databases','sidebar_server_schedules','sidebar_server_users','sidebar_server_backups','sidebar_server_network','sidebar_server_startup','sidebar_server_settings','sidebar_server_activity','sidebar_server_more','sidebar_account_account','sidebar_account_api','sidebar_account_ssh','sidebar_account_activity','sidebar_account_more'];
        foreach ($textKeys as $key) if ($request->has($key)) $settings[$key] = mb_substr(strip_tags((string)$request->input($key)),0,500);
        foreach (['weblink_support','weblink_billing','weblink_status','weblink_social_discord','weblink_social_github'] as $urlKey) {
            if (!empty($settings[$urlKey]) && !preg_match('~^https?://~i', $settings[$urlKey])) $settings[$urlKey] = '';
        }
        $uploadDir = public_path('extensions/killoratheme/uploads'); File::ensureDirectoryExists($uploadDir);
        foreach (['background_file'=>'background_url','logo_file'=>'logo_url'] as $field=>$key) if ($request->hasFile($field)) {
            $file=$request->file($field); $ext=strtolower($file->getClientOriginalExtension());
            $name=$field.'-'.Str::random(24).'.'.$ext; $file->move($uploadDir,$name); $settings[$key]='/extensions/killoratheme/uploads/'.$name;
        }
        $this->writeStoredSettings(array_merge($this->readStoredSettings(), $settings));
        return redirect()->back()->with('success','Killora Theme Studio settings saved globally for all panel users.');
    }

}
