(() => {
  'use strict';
  const CONFIG_URL = '/killora-theme/config';
  const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const memory = Number(navigator.deviceMemory || 4);
  const cores = Number(navigator.hardwareConcurrency || 4);
  const lowEnd = reduceMotion || memory <= 3 || cores <= 4 || (window.innerWidth < 720);
  const clamp = (n, min, max) => Math.min(max, Math.max(min, n));

  function applyBackground(cfg) {
    const url = cfg.background && cfg.background.url;
    const pattern = cfg.theme && cfg.theme.background_pattern;
    if (!url && (!pattern || pattern === 'none')) return;
    if (cfg.background.type === 'video' && (lowEnd || cfg.lowEndDefault)) return;
    const opacity = clamp(Number(cfg.background.opacity ?? .72), .1, 1);
    const isAuth = /login|auth|password|forgot/i.test(location.pathname);
    const filter = (cfg.theme && (isAuth ? cfg.theme.auth_background_filter : cfg.theme.background_filter)) || 'none';
    let layer = document.getElementById('killora-global-background');
    if (!layer) {
      layer = document.createElement('div'); layer.id = 'killora-global-background';
      Object.assign(layer.style, {position:'fixed',inset:'0',zIndex:'-1',pointerEvents:'none',overflow:'hidden'});
      document.body.prepend(layer);
      document.body.style.setProperty('background', 'transparent', 'important');
    }
    layer.replaceChildren();
    layer.style.filter = filter === 'blur' ? 'blur(3px)' : 'none';
    layer.style.opacity = filter === 'dim' ? String(opacity * .72) : String(opacity);
    if (cfg.background && cfg.background.type === 'video' && url) {
      const video = document.createElement('video');
      video.src = url; video.autoplay = true; video.muted = true; video.loop = true; video.playsInline = true; video.preload = 'metadata';
      Object.assign(video.style,{width:'100%',height:'100%',objectFit:'cover',opacity:String(opacity)});
      layer.appendChild(video);
      const p = video.play(); if (p && p.catch) p.catch(() => {});
    } else if(url) {
      Object.assign(layer.style,{backgroundImage:`url("${String(url).replace(/["\\]/g,'')}")`,backgroundSize:(cfg.theme&&cfg.theme.background_appearance)||'cover',backgroundPosition:'center',opacity:String(opacity)});
    }
    const patterns={'tiles':'linear-gradient(45deg,#ffffff08 25%,transparent 25%,transparent 75%,#ffffff08 75%)','cubes':'linear-gradient(30deg,#ffffff0a 12%,transparent 12.5%,transparent 87%,#ffffff0a 87.5%)','zig-zag':'repeating-linear-gradient(135deg,#ffffff08 0 2px,transparent 2px 18px)','chevrons':'repeating-linear-gradient(45deg,#ffffff08 0 1px,transparent 1px 16px)','polka':'radial-gradient(#ffffff16 1px,transparent 1px)'};
    if(patterns[pattern]){const overlay=document.createElement('div');Object.assign(overlay.style,{position:'absolute',inset:'0',backgroundImage:patterns[pattern],backgroundSize:(cfg.theme.background_pattern_size||215)+'px '+(cfg.theme.background_pattern_size||215)+'px',opacity:'.45'});layer.appendChild(overlay);}
  }

  function applyLogo(cfg) {
    const logo = cfg.logo && cfg.logo.url;
    if (!logo) return;
    const t=cfg.theme||{};
    const selectors = ['.navbar-brand img','img[alt*="logo" i]'];
    if(t.sidebar_customlogo!=='0')selectors.push('.sidebar .logo img');
    if(t.auth_customlogo!=='0')selectors.push('.login-logo img','.auth-logo img');
    document.querySelectorAll(selectors.join(',')).forEach((img) => {
      if (img.dataset.killoraLogoApplied) return;
      img.dataset.killoraLogoApplied = '1';
      if (cfg.logo.type === 'video') {
        const video = document.createElement('video'); video.src = logo; video.autoplay = true; video.loop = true; video.muted = true; video.playsInline = true;
        video.style.cssText = 'max-width:100%;max-height:64px;object-fit:contain';
        img.replaceWith(video); const p=video.play(); if(p&&p.catch)p.catch(()=>{});
      } else { img.src = logo; img.removeAttribute('srcset'); }
    });
  }

  function particleLayer(cfg) {
    if (!cfg.particles || !cfg.particles.enabled || cfg.particles.type === 'none' || reduceMotion) return;
    const canvas = document.createElement('canvas'); canvas.id = 'killora-particles';
    canvas.setAttribute('aria-hidden','true');
    Object.assign(canvas.style,{position:'fixed',inset:'0',width:'100%',height:'100%',pointerEvents:'none',zIndex:'5'});
    document.body.appendChild(canvas);
    const ctx = canvas.getContext('2d',{alpha:true}); if (!ctx) { canvas.remove(); return; }
    const dpr = Math.min(window.devicePixelRatio || 1, lowEnd ? 1 : 1.25);
    let width=0,height=0,raf=0,last=0,items=[];
    const maxCount = lowEnd ? 14 : 64;
    const density = clamp(Number(cfg.particles.density || 30),0,100);
    const count = Math.min(maxCount, Math.round(density * (lowEnd ? .14 : .64)));
    const speed = clamp(Number(cfg.particles.speed || 1),.2,3) * (lowEnd ? .55 : 1);
    const alpha = clamp(Number(cfg.particles.opacity ?? .75),0,1);
    const symbols = {
      'cherry-blossom':['✿','❀'],'fire':['•','✦'],'diamond-rain':['◆','◇'],'snow':['❄','✧'],
      'stars':['✦','⋆','✧'],'purple-magic':['✧','✦','·'],'rain':['│','╎'],'leaves':['❧','✿'],'sparkles':['✧','✦']
    }[cfg.particles.type] || ['·'];
    const colors = {'fire':['#ffb15c','#ff7043'],'diamond-rain':['#7dd3fc','#c4b5fd'],'snow':['#ffffff','#c7e8ff'],'cherry-blossom':['#ffc6df','#ff9fc9'],'leaves':['#a7f3d0','#bef264'],'rain':['#93c5fd'],'stars':['#fff1a8','#c4b5fd'],'purple-magic':['#c4b5fd','#a78bfa'],'sparkles':['#fff','#c4b5fd']};
    const palette = colors[cfg.particles.type] || ['#c4b5fd'];
    function resize(){ width=window.innerWidth; height=window.innerHeight; canvas.width=Math.round(width*dpr); canvas.height=Math.round(height*dpr); ctx.setTransform(dpr,0,0,dpr,0,0); }
    function spawn(initial=false){return {x:Math.random()*width,y:initial?Math.random()*height:-12,v: (0.35+Math.random()*1.1)*speed, drift:(Math.random()-.5)*.5, size:8+Math.random()*9, symbol:symbols[Math.floor(Math.random()*symbols.length)], color:palette[Math.floor(Math.random()*palette.length)], phase:Math.random()*6.28};}
    function reset(){items=Array.from({length:count},()=>spawn(true));}
    function draw(ts){
      if (document.hidden) { raf=0; return; }
      if (ts-last < (lowEnd?66:40)) { raf=requestAnimationFrame(draw); return; }
      last=ts; ctx.clearRect(0,0,width,height);
      for(let i=0;i<items.length;i++){
        const p=items[i]; p.y+=p.v; p.x+=p.drift+Math.sin(ts*.0006+p.phase)*.22;
        ctx.globalAlpha=alpha; ctx.fillStyle=p.color; ctx.font=`${p.size}px system-ui,sans-serif`; ctx.fillText(p.symbol,p.x,p.y);
        if(p.y>height+18 || p.x<-20 || p.x>width+20) items[i]=spawn(false);
      }
      ctx.globalAlpha=1; raf=requestAnimationFrame(draw);
    }
    resize(); reset(); const start=()=>{if(!raf&&!document.hidden)raf=requestAnimationFrame(draw);}; const stop=()=>{if(raf)cancelAnimationFrame(raf);raf=0;};
    document.addEventListener('visibilitychange',()=>document.hidden?stop():start(),{passive:true});
    window.addEventListener('resize',()=>{resize();reset();},{passive:true}); start();
  }

  function applyGlass(cfg){
    const blur=clamp(Number(cfg.glassBlur ?? 16),0,30);
    const nodes=document.querySelectorAll('.login-box,.login-card,.auth-card,.auth-container form,form[action*="login"]');
    nodes.forEach(el=>{el.style.setProperty('background','rgba(13,17,35,.56)','important');el.style.setProperty('border','1px solid rgba(255,255,255,.16)','important');el.style.setProperty('backdrop-filter',`blur(${blur}px)`,'important');el.style.setProperty('-webkit-backdrop-filter',`blur(${blur}px)`,'important');el.style.setProperty('box-shadow','0 18px 60px rgba(0,0,0,.28)','important');el.style.setProperty('border-radius','20px','important');});
  }

  function applyThemeOptions(cfg) {
    const t = cfg.theme || {}, p = cfg.palette || {};
    const root = document.documentElement;
    const vars = {
      '--killora-radius': `${clamp(Number(t.border_radius ?? 14),0,30)}px`,
      '--killora-sidebar-radius': `${clamp(Number(t.sidebar_border_radius ?? 12),0,30)}px`,
      '--killora-icon-scale': String(clamp(Number(t.icon_scale ?? .9),.5,1.8)),
      '--killora-glass-blur': `${clamp(Number(cfg.glassBlur ?? 16),0,30)}px`,
    };
    (p.dashboard || []).forEach((color,i)=>{ if(/^#[0-9a-f]{6}$/i.test(color)) vars[`--killora-palette-${i+1}`]=color; });
    (p.sidebar || []).forEach((color,i)=>{ if(/^#[0-9a-f]{6}$/i.test(color)) vars[`--killora-sidebar-palette-${i+1}`]=color; });
    Object.entries(p.status || {}).forEach(([key,color])=>{if(/^#[0-9a-f]{6}$/i.test(color))vars[`--killora-status-${key}`]=color;});
    Object.entries(vars).forEach(([key,value])=>root.style.setProperty(key,value));

    const radius = vars['--killora-radius'];
    document.querySelectorAll('.content-card,.server-card,.server-list,.card,.panel-card').forEach(el=>{
      el.style.borderRadius=radius;
      if (t.dashboard_transparency === '1') el.style.backgroundColor='rgba(17,22,40,.92)';
      if (t.dashboard_transparency === '2') el.style.backgroundColor='rgba(17,22,40,.76)';
      if (t.dashboard_transparency === '3') {el.style.backgroundColor='rgba(17,22,40,.56)';el.style.backdropFilter='blur(10px)';}
    });
    const sidebar=document.querySelector('#sidebar,.sidebar,nav[aria-label="Sidebar"]');
    if(sidebar){
      sidebar.style.borderRadius=vars['--killora-sidebar-radius'];
      if(t.sidebar_background==='glass'){sidebar.style.background='rgba(11,15,31,.72)';sidebar.style.backdropFilter='blur(14px)';}
      if(t.sidebar_background==='solid')sidebar.style.background='rgba(11,15,31,.98)';
      if(t.sidebar_separators==='0')sidebar.querySelectorAll('hr,.sidebar-divider').forEach(el=>el.style.display='none');
    }
    if(t.animations==='disabled'||reduceMotion) root.classList.add('killora-no-animations');
    else root.dataset.killoraAnimation=t.animations;
    if(t.server_list==='list') root.classList.add('killora-server-list');
    if(t.statusgradient_style==='flat') root.classList.add('killora-flat-status');
    if(t.sidebar_buttonstyle) root.dataset.killoraSidebarButtons=t.sidebar_buttonstyle;
    if(t.sidebar_hover) root.dataset.killoraSidebarHover=t.sidebar_hover;
    if(t.keyboard_shortcuts==='0') root.dataset.killoraShortcuts='off';
    if(t.server_overview_graphs==='0') document.querySelectorAll('.server-overview-graph,.server-graph').forEach(el=>el.style.display='none');
    if(t.server_colored_power==='0') root.classList.add('killora-neutral-power');

    // Replace visible navigation labels by their matching route href, without touching route URLs.
    const labels = {
      '/':t.sidebar_home, '/admin':t.sidebar_admin, '/account':t.sidebar_account,
      '/account':t.sidebar_account, '/server/':null,
    };
    Object.entries(labels).forEach(([href,label])=>{
      if(!label)return;
      document.querySelectorAll(`a[href="${href}"]`).forEach(a=>{const textNode=[...a.childNodes].find(n=>n.nodeType===Node.TEXT_NODE&&n.textContent.trim());if(textNode)textNode.textContent=' '+label;});
    });
    const navMap = {'console':'sidebar_server_terminal','files':'sidebar_server_files','databases':'sidebar_server_databases','schedules':'sidebar_server_schedules','users':'sidebar_server_users','backups':'sidebar_server_backups','network':'sidebar_server_network','startup':'sidebar_server_startup','settings':'sidebar_server_settings','activity':'sidebar_server_activity'};
    document.querySelectorAll('a[href]').forEach(a=>{const href=a.getAttribute('href')||'';for(const [part,key] of Object.entries(navMap)){if(href.endsWith('/'+part)&&t[key]){const node=[...a.childNodes].find(n=>n.nodeType===Node.TEXT_NODE&&n.textContent.trim());if(node)node.textContent=' '+t[key];break;}}});
  }

  function applyExtras(cfg) {
    const t=cfg.theme||{};
    if(cfg.announcement&&cfg.announcement.enabled&&cfg.announcement.text&&!document.getElementById('killora-announcement')){
      const bar=document.createElement('div');bar.id='killora-announcement';bar.textContent=cfg.announcement.text;
      Object.assign(bar.style,{position:cfg.announcement.position==='sticky'?'sticky':'relative',top:'0',zIndex:'1000',padding:'10px 16px',textAlign:'center',background:'linear-gradient(90deg,#31205e,#202b58)',color:'#f4f1ff',fontSize:'13px',borderBottom:'1px solid #a78bfa55'});
      if(cfg.announcement.dismissible){const close=document.createElement('button');close.type='button';close.textContent='×';close.setAttribute('aria-label','Dismiss announcement');Object.assign(close.style,{marginLeft:'14px',border:0,background:'transparent',color:'inherit',fontSize:'20px',cursor:'pointer'});close.addEventListener('click',()=>{bar.remove();try{sessionStorage.setItem('killora-announcement-dismissed','1')}catch(e){}});bar.appendChild(close);try{if(sessionStorage.getItem('killora-announcement-dismissed')==='1')return}catch(e){}}
      document.body.prepend(bar);
    }
    if(cfg.links&&cfg.links.enabled&&cfg.links.items&&!document.getElementById('killora-website-links')){
      const valid=Object.entries(cfg.links.items).filter(([label,url])=>/^https?:\/\//i.test(url));
      if(valid.length){const nav=document.createElement('nav');nav.id='killora-website-links';nav.setAttribute('aria-label','Website links');Object.assign(nav.style,{display:'flex',gap:'14px',justifyContent:cfg.links.align==='right'?'flex-end':'flex-start',flexWrap:'wrap',padding:'12px 18px',fontSize:'12px'});valid.forEach(([label,url])=>{const a=document.createElement('a');a.href=url;a.textContent=label;a.target='_blank';a.rel='noopener noreferrer';a.style.color='#c4b5fd';nav.appendChild(a)});document.body.appendChild(nav);}
    }
  }

  function applyRegistration(cfg){
    if(!cfg.registrationEnabled || !/login/i.test(location.pathname)) return;
    if(document.getElementById('killora-register-link')) return;
    const forms=[...document.querySelectorAll('form')];
    const form=forms.find(f=>f.querySelector('input[type="password"]') && (f.querySelector('input[type="email"]') || f.querySelector('input[name*="email" i]')));
    if(!form) return;
    const wrap=document.createElement('div');
    wrap.id='killora-register-link';
    wrap.style.cssText='margin-top:16px;text-align:center;font-size:13px;color:#cbd5e1';
    const label=document.createElement('span'); label.textContent="Don't have an account? ";
    const link=document.createElement('a'); link.href='/extensions/killoratheme/register'; link.textContent='Create account';
    link.style.cssText='color:#c4b5fd;font-weight:700;text-decoration:none';
    wrap.append(label,link); form.insertAdjacentElement('afterend',wrap);
  }

  function enableLowEnd(cfg){
    if (!lowEnd && !cfg.lowEndDefault) return;
    document.documentElement.classList.add('killora-low-end');
    const style=document.createElement('style'); style.textContent='.killora-low-end *, .killora-low-end *::before, .killora-low-end *::after{animation-duration:.01ms!important;animation-iteration-count:1!important;transition-duration:.01ms!important;scroll-behavior:auto!important}.killora-low-end #killora-particles{display:none!important}.killora-low-end #killora-global-background video{display:none!important}.killora-no-animations *, .killora-no-animations *::before, .killora-no-animations *::after{animation:none!important;transition:none!important}';
    document.head.appendChild(style);
  }

  function start(){
    if (!document.body || document.getElementById('killora-theme-runtime')) return;
    const marker=document.createElement('meta'); marker.id='killora-theme-runtime'; marker.name='killora-theme-runtime'; marker.content='1'; document.head.appendChild(marker);
    fetch(CONFIG_URL,{credentials:'same-origin',cache:'no-store',headers:{'Accept':'application/json'}})
      .then(r=>r.ok?r.json():null).then(cfg=>{if(!cfg)return;applyBackground(cfg);applyLogo(cfg);applyGlass(cfg);applyThemeOptions(cfg);applyExtras(cfg);applyRegistration(cfg);enableLowEnd(cfg);particleLayer(cfg);})
      .catch(()=>{});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
