# Killora Theme — Standalone / Non-Blueprint

Standalone integration for a standard Laravel-based Pterodactyl Panel. It does **not** require Blueprint or its database library.

## Install

1. Back up your panel files and database.
2. Upload/extract this package on the panel server.
3. Run as root:

   `bash install.sh /var/www/pterodactyl`

4. Open the Admin panel. Root administrators get a floating **Killora Theme Editor** shortcut. Direct route: `/killora-theme/editor`.

The installer backs up `routes/web.php` under `storage/app/killoratheme-backup-*`, installs the controller and Blade views, registers standalone routes, and adds the runtime script to the standard admin/client layouts when those layout files exist.

## Storage

- Global settings: `storage/app/killoratheme/settings.json`
- Uploaded media: `public/extensions/killoratheme/uploads`
- Public runtime assets: `public/extensions/killoratheme/assets`

Settings are server-side and shared across panel users. Editor and save routes require authentication and `root_admin`. The public config endpoint only exposes display settings. Registration is disabled by default and, if enabled, creates non-admin users only.

## Important compatibility notes

This is a standalone Laravel/Pterodactyl integration, not a Blueprint package. Pterodactyl releases can change their Blade layout paths and Laravel bootstrapping. The installer adds the editor shortcut to `resources/views/layouts/admin.blade.php` and the runtime to the standard admin/client layouts if found. If your panel uses different layout paths, the editor route still exists and the runtime script can be included in the corresponding layouts manually.

Run the install on a backup or staging panel first. This archive has been structurally and syntax checked, but it has not been installed against your live panel; verify login, admin/client pages, media uploads, registration and settings persistence after installation.
