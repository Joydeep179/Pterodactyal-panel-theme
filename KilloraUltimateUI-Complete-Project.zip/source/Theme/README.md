# Killora Ultimate UI Theme layer

This is a separate Blueprint classic extension package (`killoratheme`) using documented `dashboard.css` and `dashboard.wrapper` bindings. It reads visual settings written by the main `killora` extension from `ext_killora_settings`. Install the main extension first, then this theme package. The theme package is intentionally separate so administrators can disable the visual layer without removing the settings dashboard.

The CSS uses conservative selectors and CSS variables. Exact coverage of every Pterodactyl React screen requires browser validation against the exact compiled frontend and may need selector adjustments.
