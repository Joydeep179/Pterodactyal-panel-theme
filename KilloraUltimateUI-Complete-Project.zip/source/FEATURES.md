# Feature matrix — 0.1.1

Implemented in source: Blueprint classic extension structure; admin branding/color/media settings; database persistence; Laravel validation; PNG/JPEG/WEBP/GIF logo and background uploads; dashboard CSS and CSS-variable wrapper; four quick presets; responsive settings view; reduced-motion CSS; lifecycle scripts preserving settings/media.

Not implemented: full redesign of every user/admin route; independent theme-only package; login branding; SVG or video uploads; advanced media controls; particle effects; seven presets/custom preset CRUD; import/export; device-frame preview; native registration/account creation/email verification; live integration tests.
