#!/usr/bin/env bash
set -euo pipefail
# Blueprint owns file placement and migration execution. Do not edit Panel core files.
echo "Killora Ultimate UI files installed. Ensure Laravel public storage is linked for uploads."
