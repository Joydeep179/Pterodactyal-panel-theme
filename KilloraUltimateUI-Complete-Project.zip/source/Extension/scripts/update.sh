#!/usr/bin/env bash
set -euo pipefail
# Settings are stored in ext_killora_settings and intentionally preserved across updates.
echo "Killora Ultimate UI update: preserving database settings and public media."
