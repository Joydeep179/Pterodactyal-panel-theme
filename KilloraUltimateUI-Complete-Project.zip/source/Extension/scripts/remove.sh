#!/usr/bin/env bash
set -euo pipefail
# Deliberately preserve ext_killora_settings and uploaded media to avoid data loss.
echo "Killora Ultimate UI removed. Settings/media were preserved intentionally."
