<?php
try {
    $k = \Illuminate\Support\Facades\DB::table('ext_killora_settings')->pluck('value', 'key')->toArray();
    $safeColor = function ($key, $fallback) use ($k) {
        $value = $k[$key] ?? $fallback;
        return preg_match('/^#[0-9a-fA-F]{6}$/', $value) ? $value : $fallback;
    };
?>
<style>
:root {
 --killora-primary: <?= $safeColor('primary_color','#8b5cf6') ?>;
 --killora-secondary: <?= $safeColor('secondary_color','#312e81') ?>;
 --killora-accent: <?= $safeColor('accent_color','#22d3ee') ?>;
 --killora-bg: <?= $safeColor('background_color','#090b14') ?>;
 --killora-card: <?= $safeColor('card_background','#151827') ?>;
 --killora-sidebar: <?= $safeColor('sidebar_background','#101321') ?>;
 --killora-text: <?= $safeColor('text_color','#f4f4f5') ?>;
 --killora-muted: <?= $safeColor('muted_text_color','#a1a1aa') ?>;
}
<?php if (!empty($k['background_url'])): ?>
body { background-image:linear-gradient(#090b14aa,#090b14aa),url("<?= e($k['background_url']) ?>");background-size:cover;background-position:center;background-attachment:fixed; }
<?php endif; ?>
</style>
<?php } catch (\Throwable $e) { /* Keep the native panel available if settings are unavailable. */ } ?>
