<?php $settings = $settings ?? []; ?>
<div class="killora-admin">
  <div class="killora-hero">
    <div><span class="killora-eyebrow">KILLORA CLOUD / CONTROL CENTER</span><h1>Ultimate UI</h1>
    <p>Customize your panel identity and visual system. Changes are stored in the panel database.</p></div>
    <span class="killora-version">v0.1.0 · Blueprint</span>
  </div>
  @if (session('killora_status'))
    <div class="killora-notice">{{ session('killora_status') }}</div>
  @endif
  @if ($errors->any())
    <div class="killora-error">@foreach ($errors->all() as $error)<div>{{ $error }}</div>@endforeach</div>
  @endif
  <form method="POST" action="{{ $root }}" enctype="multipart/form-data" id="killora-form">
    @csrf
    <div class="killora-layout">
      <aside class="killora-tabs">
        <button type="button" class="active" data-tab="general">General & Branding</button>
        <button type="button" data-tab="colors">Color manager</button>
        <button type="button" data-tab="media">Logo & Background</button>
        <button type="button" data-tab="preview">Live preview</button>
        <button type="button" data-tab="status">Release status</button>
      </aside>
      <main class="killora-content">
        <section class="killora-tab active" id="tab-general">
          <h2>General & branding</h2><p class="killora-muted">Set the visible identity used by the theme.</p>
          <div class="killora-grid">
            <label>Hosting name<input name="hosting_name" value="{{ old('hosting_name', $settings['hosting_name']) }}" maxlength="80"></label>
            <label>Browser page title<input name="page_title" value="{{ old('page_title', $settings['page_title']) }}" maxlength="100"></label>
            <label>Main heading<input name="main_heading" value="{{ old('main_heading', $settings['main_heading']) }}" maxlength="120"></label>
            <label>Welcome heading<input name="welcome_heading" value="{{ old('welcome_heading', $settings['welcome_heading']) }}" maxlength="120"></label>
            <label class="wide">Welcome subtitle<textarea name="welcome_subtitle" maxlength="250">{{ old('welcome_subtitle', $settings['welcome_subtitle']) }}</textarea></label>
            <label>Footer text<input name="footer_text" value="{{ old('footer_text', $settings['footer_text']) }}" maxlength="160"></label>
            <label>Discord invite URL<input name="discord_url" type="url" value="{{ old('discord_url', $settings['discord_url'] ?? '') }}" maxlength="255" placeholder="https://discord.gg/..."></label>
            <label class="wide">Custom description<textarea name="description" maxlength="300">{{ old('description', $settings['description'] ?? '') }}</textarea></label>
          </div>
        </section>
        <section class="killora-tab" id="tab-colors">
          <h2>Color manager</h2><p class="killora-muted">Changes are previewed instantly and saved when you apply them.</p>
          <div class="killora-grid">
            <?php foreach (['primary_color'=>'Primary','secondary_color'=>'Secondary','accent_color'=>'Accent','background_color'=>'Background','card_background'=>'Card background','sidebar_background'=>'Sidebar background','text_color'=>'Text','muted_text_color'=>'Muted text'] as $key=>$label): ?>
              <label class="color-field"><?= e($label) ?><span><input type="color" name="<?= e($key) ?>" value="<?= e($settings[$key]) ?>"><code><?= e($settings[$key]) ?></code></span></label>
            <?php endforeach; ?>
          </div>
          <div class="killora-presets"><strong>Quick presets</strong>
            <button type="button" data-preset="purple">Midnight Purple</button><button type="button" data-preset="ocean">Ocean Blue</button>
            <button type="button" data-preset="crimson">Crimson Red</button><button type="button" data-preset="amoled">AMOLED Black</button>
          </div>
        </section>
        <section class="killora-tab" id="tab-media">
          <h2>Logo & background</h2><p class="killora-muted">Uploads are stored on Laravel's public disk. Ensure public/storage is linked.</p>
          <div class="killora-grid">
            <label>Panel logo (PNG/JPG/WEBP/GIF)<input type="file" name="logo" accept=".png,.jpg,.jpeg,.webp,.gif"></label>
            <label>Panel background (PNG/JPG/WEBP/GIF)<input type="file" name="background" accept=".png,.jpg,.jpeg,.webp,.gif"></label>
          </div>
          <p class="killora-warning">Video backgrounds and animated particle systems are not part of this verified starter release.</p>
          @if(!empty($settings['logo_url']))<p>Current logo: <a href="{{ $settings['logo_url'] }}" target="_blank" rel="noopener">View uploaded logo</a></p>@endif
          @if(!empty($settings['background_url']))<p>Current background: <a href="{{ $settings['background_url'] }}" target="_blank" rel="noopener">View uploaded background</a></p>@endif
        </section>
        <section class="killora-tab" id="tab-preview">
          <h2>Live preview</h2><p class="killora-muted">This preview mirrors the saved theme tokens and editable text fields.</p>
          <div class="killora-preview" id="killora-preview">
            <div class="kp-nav"><b id="kp-brand">Killora Cloud</b><span>Dashboard　 Servers　 Account</span></div>
            <div class="kp-card"><span class="kp-chip">CONTROL PANEL</span><h2 id="kp-heading">Welcome to Killora Cloud</h2><p id="kp-subtitle">Manage your game servers from one powerful control panel.</p><button type="button">Open dashboard</button></div>
          </div>
          <div class="killora-preview-actions"><button type="button" id="preview-reset">Reset preview</button><button type="submit" class="primary">Save & apply changes</button></div>
        </section>
        <section class="killora-tab" id="tab-status">
          <h2>Implementation status</h2>
          <ul class="killora-status-list">
            <li>Database-backed branding and color settings</li><li>Validated logo/background uploads</li><li>Client dashboard CSS and wrapper integration</li><li>Live form preview and quick color presets</li>
          </ul>
          <p class="killora-warning">This release does not claim full page-by-page React restyling, registration/authentication changes, video backgrounds, per-surface media controls, animation effects, import/export, or cross-device preview. Those require additional version-specific integration and testing on your panel.</p>
        </section>
        <div class="killora-savebar"><span>Unsaved edits remain in this browser until submitted.</span><button type="submit" class="primary">Save changes</button></div>
      </main>
    </div>
  </form>
</div>
<script>
(function(){
 const root=document.getElementById('killora-form'); if(!root)return;
 const tabs=[...document.querySelectorAll('.killora-tabs button')];
 tabs.forEach(b=>b.addEventListener('click',()=>{tabs.forEach(x=>x.classList.toggle('active',x===b));document.querySelectorAll('.killora-tab').forEach(x=>x.classList.toggle('active',x.id==='tab-'+b.dataset.tab));}));
 const presets={
 purple:{primary_color:'#8b5cf6',secondary_color:'#312e81',accent_color:'#22d3ee',background_color:'#090b14',card_background:'#151827',sidebar_background:'#101321',text_color:'#f4f4f5',muted_text_color:'#a1a1aa'},
 ocean:{primary_color:'#0ea5e9',secondary_color:'#164e63',accent_color:'#67e8f9',background_color:'#07131c',card_background:'#102431',sidebar_background:'#0b1b27',text_color:'#effaff',muted_text_color:'#9bb8c7'},
 crimson:{primary_color:'#ef4444',secondary_color:'#7f1d1d',accent_color:'#fb923c',background_color:'#160b10',card_background:'#25131b',sidebar_background:'#1b0e15',text_color:'#fff1f2',muted_text_color:'#d4a6ad'},
 amoled:{primary_color:'#a78bfa',secondary_color:'#4c1d95',accent_color:'#22d3ee',background_color:'#000000',card_background:'#090909',sidebar_background:'#030303',text_color:'#ffffff',muted_text_color:'#a3a3a3'}
 };
 function val(n){const e=root.elements[n];return e?e.value:''}
 function update(){
  const p=document.getElementById('killora-preview'); if(!p)return;
  p.style.setProperty('--kp-primary',val('primary_color')||'#8b5cf6');
  p.style.setProperty('--kp-bg',val('background_color')||'#090b14');
  p.style.setProperty('--kp-card',val('card_background')||'#151827');
  p.style.setProperty('--kp-text',val('text_color')||'#f4f4f5');
  document.getElementById('kp-brand').textContent=val('hosting_name')||'Killora Cloud';
  document.getElementById('kp-heading').textContent=val('welcome_heading')||'Welcome';
  document.getElementById('kp-subtitle').textContent=val('welcome_subtitle')||'';
 }
 root.addEventListener('input',update);
 document.querySelectorAll('[data-preset]').forEach(b=>b.addEventListener('click',()=>{Object.entries(presets[b.dataset.preset]).forEach(([k,v])=>{if(root.elements[k])root.elements[k].value=v;});update();}));
 document.getElementById('preview-reset')?.addEventListener('click',()=>{root.reset();update();});
 update();
})();
</script>
