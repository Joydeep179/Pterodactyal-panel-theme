#!/usr/bin/env bash
set -euo pipefail
echo '[Killora] Updating; settings and media preserved.'
