#!/usr/bin/env bash
set -euo pipefail
echo '[Killora] Installed; no Panel core files patched.'
