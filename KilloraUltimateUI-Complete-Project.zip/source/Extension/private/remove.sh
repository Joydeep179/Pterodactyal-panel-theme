#!/usr/bin/env bash
set -euo pipefail
echo '[Killora] Removed; settings and media intentionally retained.'
