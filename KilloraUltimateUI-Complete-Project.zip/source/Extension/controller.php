<?php
namespace Pterodactyl\Http\Controllers\Admin\Extensions\killora;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Illuminate\View\Factory as ViewFactory;
use Illuminate\View\View;
use Pterodactyl\BlueprintFramework\Libraries\ExtensionLibrary\Admin\BlueprintAdminLibrary;
use Pterodactyl\Http\Controllers\Controller;
class killoraExtensionController extends Controller {
 public function __construct(private ViewFactory $view, private BlueprintAdminLibrary $blueprint) {}
 public function index(): View {
  $settings=DB::table('ext_killora_settings')->pluck('value','key')->toArray();
  return $this->view->make('admin.extensions.killora.view',['root'=>'/admin/extensions/killora','blueprint'=>$this->blueprint,'settings'=>$settings]);
 }
 public function post(Request $request): RedirectResponse {
  $v=$request->validate([
   'hosting_name'=>'nullable|string|max:80','page_title'=>'nullable|string|max:100','main_heading'=>'nullable|string|max:120','welcome_heading'=>'nullable|string|max:120','welcome_subtitle'=>'nullable|string|max:250','footer_text'=>'nullable|string|max:160','discord_url'=>'nullable|url|max:255','description'=>'nullable|string|max:300',
   'primary_color'=>['nullable','regex:/^#[0-9A-Fa-f]{6}$/'],'secondary_color'=>['nullable','regex:/^#[0-9A-Fa-f]{6}$/'],'accent_color'=>['nullable','regex:/^#[0-9A-Fa-f]{6}$/'],'background_color'=>['nullable','regex:/^#[0-9A-Fa-f]{6}$/'],'card_background'=>['nullable','regex:/^#[0-9A-Fa-f]{6}$/'],'sidebar_background'=>['nullable','regex:/^#[0-9A-Fa-f]{6}$/'],'text_color'=>['nullable','regex:/^#[0-9A-Fa-f]{6}$/'],'muted_text_color'=>['nullable','regex:/^#[0-9A-Fa-f]{6}$/'],
   'logo'=>'nullable|file|mimes:png,jpg,jpeg,webp,gif|max:4096','background'=>'nullable|file|mimes:png,jpg,jpeg,webp,gif|max:12288'
  ]);
  foreach(['hosting_name','page_title','main_heading','welcome_heading','welcome_subtitle','footer_text','discord_url','description','primary_color','secondary_color','accent_color','background_color','card_background','sidebar_background','text_color','muted_text_color'] as $key){
   if(array_key_exists($key,$v)) DB::table('ext_killora_settings')->updateOrInsert(['key'=>$key],['value'=>(string)($v[$key]??''),'updated_at'=>now(),'created_at'=>now()]);
  }
  foreach(['logo'=>'logo_url','background'=>'background_url'] as $field=>$setting){
   if(!$request->hasFile($field)) continue; $file=$request->file($field);
   if(!$file || !$file->isValid()) throw ValidationException::withMessages([$field=>'Invalid upload.']);
   if(!in_array($file->getMimeType(),['image/png','image/jpeg','image/webp','image/gif'],true)) throw ValidationException::withMessages([$field=>'Only PNG, JPEG, WEBP and GIF are accepted.']);
   $name=$field.'-'.Str::random(40).'.'.strtolower($file->extension()?:'img'); $path=$file->storeAs('extensions/killora',$name,'public');
   if(!$path) throw ValidationException::withMessages([$field=>'Could not store file.']);
   DB::table('ext_killora_settings')->updateOrInsert(['key'=>$setting],['value'=>Storage::disk('public')->url($path),'updated_at'=>now(),'created_at'=>now()]);
  }
  return redirect('/admin/extensions/killora')->with('killora_status','Settings saved successfully.');
 }
}
