# Update
Back up Panel, database and `storage/app/public/extensions/killora`. Test updates on staging. Use Blueprint's update workflow for identifier `killora`; do not force an incompatible target. Settings/media are preserved. Clear views after updating.
