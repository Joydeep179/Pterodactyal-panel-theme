# Uninstall
Back up Panel, database and media. Use Blueprint removal for identifier `killora` (normally `blueprint -remove killora`), then run `php artisan view:clear`. Settings table and uploaded media are deliberately retained. To erase them, back them up first, then manually drop `ext_killora_settings` and remove `storage/app/public/extensions/killora`.
