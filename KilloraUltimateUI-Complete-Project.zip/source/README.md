# KILLORA ULTIMATE UI 0.1.1

One ZIP contains a Blueprint classic extension package, source and docs. This initial release implements a branding/color settings page, image uploads, local preview, four presets and a conservative dashboard CSS/wrapper layer. It is not the full original feature list; see FEATURES.md and TESTING.md. Compatibility with Pterodactyl v1.15.2 is unverified.
